﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Breakout
{
    class Nova
    {
        private bool pokretan;
        private string opis;

        public bool Pokretan
        {
            get { return pokretan; }
            set { pokretan = value; }
        }

        public string Opis
        {
            get { return opis; }
            set { opis = value; }
        }

    }
}
